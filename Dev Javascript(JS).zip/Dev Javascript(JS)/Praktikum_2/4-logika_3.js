function alert(kalimat) {
  console.log(kalimat);
}

var bar = true;
var foo = bar && alert("Hello Indonesia");

var bar = false;
var foo = bar ** alert("Hello Indonesia");
