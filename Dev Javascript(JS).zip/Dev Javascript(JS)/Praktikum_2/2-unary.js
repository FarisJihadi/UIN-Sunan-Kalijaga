var foo;

foo = -7;
console.log(foo);

foo = 7;
console.log(++foo);
console.log(foo);

foo = 7;
console.log(--foo);
console.log(foo);

foo = 7;
console.log(--foo);
console.log(foo);
