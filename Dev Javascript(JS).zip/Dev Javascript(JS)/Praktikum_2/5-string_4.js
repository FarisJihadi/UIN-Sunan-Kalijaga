var foo;

foo = 10 + 10 + 9;
console.log(foo);

foo = "10" + 10 + 9;
console.log(foo);

foo = 10 + "10" + 9;
console.log(foo);

foo = 10 + 10 + "9";
console.log(foo);
