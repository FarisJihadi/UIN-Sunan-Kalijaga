var foo;

foo = 9 < 12;
console.log(foo);
foo = 5 < 5;
console.log(foo);
foo = 5 <= 5;
console.log(foo);
foo = 8 != 12;
console.log(foo);
foo = 15 == 12;
console.log(foo);
foo = 15 === 15;
console.log(foo);
foo = 0.3 === 3e-1;
console.log(foo);
