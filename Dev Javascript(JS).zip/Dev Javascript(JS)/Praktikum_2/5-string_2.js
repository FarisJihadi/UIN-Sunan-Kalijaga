var foo, bar, baz;
var siswa = ["Andri", "Joko", "Sukma", "Rina", "Sari"];

foo = siswa[1] + " mendapat penghargaan sebagai siswa teladan";
console.log(foo);

bar = siswa[3] + " dan " + siswa[4] + " adalah teman akrab";
console.log(bar);

baz = "Dalam ujian kemarin, " + siswa[0] + " mendapat nilai " + 4 * 20;
console.log(baz);
