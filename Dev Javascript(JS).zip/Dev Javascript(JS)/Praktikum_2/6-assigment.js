var a = 12;
var b = "Belajar";

a += 10;
a += a + 5;
console.log(a);

b += " JavaScript";
b += " dari buku JavaScript Uncover";
console.log(b);

a /= 7;
console.log(a);

a -= 5;
console.log(a);
