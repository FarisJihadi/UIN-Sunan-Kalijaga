var foo;

foo = "a" < "b";
console.log(foo);

foo = "a" < "A";
console.log(foo);

foo = "reva" < "revika";
console.log(foo);

foo = false < true;
console.log(foo);

foo = "joni" == 12;
console.log(foo);
