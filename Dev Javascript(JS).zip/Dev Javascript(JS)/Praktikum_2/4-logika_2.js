var foo;
foo = true || false || true;
console.log(foo);

foo = false && true && true;
console.log(foo);
