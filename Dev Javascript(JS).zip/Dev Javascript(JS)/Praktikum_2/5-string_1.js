var foo, bar, baz;
foo = "Sedang " + "Belajar " + "JavaScript ";
console.log(foo);

foo = "Belajar " + "ECMAScript " + 7;
console.log(foo);

foo = "Selamaat ";
bar = "Malan ";
baz = "Indonesia ";
hasil = foo + bar + baz;
console.log(hasil);
