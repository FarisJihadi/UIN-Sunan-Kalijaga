let X = 10;

console.log("Nilai awal X: " + X);

X += 5;
console.log("Setelah += 5: " + X);

X *= 2;
console.log("Setelah *= 2: " + X);

X %= 4;
console.log("Setelah %= 4: " + X);
