let a = 10;
let b = 5;

let isGreater = a > b;
let isEqual = a === b;

console.log("isGreater && isEqual: " + (isGreater && isEqual));
console.log("isGreater || isEqual: " + (isGreater || isEqual));
console.log("!isGreater: " + !isGreater);
