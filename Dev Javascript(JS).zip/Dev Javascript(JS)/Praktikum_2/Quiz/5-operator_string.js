let namaDepan = "Faris";
let namaBelakang = "Jihadi";
let NIM = "23106050031";
let teman = ["Agung", "Bayu", "emul", "Azzam", "Radipta"];

let hasil =
  namaDepan +
  " " +
  namaBelakang +
  " (" +
  NIM +
  ") - Teman: " +
  teman[0] +
  ", " +
  teman[1] +
  ", " +
  teman[2];
console.log(hasil);
