let angka = 10;
console.log("Nilai awal: " + angka);

angka++;
console.log("Setelah ++ : " + angka);

angka--;
console.log("Setelah -- " + angka);

angka = -angka;
console.log("Setelah negasi: " + angka);
