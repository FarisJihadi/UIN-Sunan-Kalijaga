const tinggi = 20;
const sisi = 5;
const alas = 4;
let volume = ((sisi * alas) / 2) * tinggi;

console.log("Volume Prisma: " + volume + " cm");
