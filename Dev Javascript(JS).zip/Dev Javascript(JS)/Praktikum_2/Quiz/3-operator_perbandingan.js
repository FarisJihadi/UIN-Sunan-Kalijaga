let nilai1 = 10;
let nilai1str = "10";
let nilai2 = 20;

console.log("nilai1 > nilai2: " + (nilai1 > nilai2));
console.log("nilai1 >= nilai2: " + (nilai1 >= nilai2));
console.log("nilai1 == nilai2: " + (nilai1 == nilai2));
console.log("nilai1 === nilai2: " + (nilai1 === nilai2));
console.log("nilai1 !== nilai2: " + (nilai1 !== nilai2));

console.log("nilai1 < nilai2: " + (nilai1str > nilai2));
console.log("nilai1 > nilai2: " + (nilai1str > nilai2));
