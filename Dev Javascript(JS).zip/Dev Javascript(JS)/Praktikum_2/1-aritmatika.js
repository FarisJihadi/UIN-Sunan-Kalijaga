var foo;

foo = 30 + 5;
console.log(foo);

foo = 3.33 + 9.02;
console.log(foo);

foo = 9 * 7;
console.log(foo);

foo = 6 + 8 / 2 + 6;
console.log(foo);

foo = 10 % 7;
console.log(foo);
