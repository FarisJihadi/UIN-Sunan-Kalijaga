// expression
const age = 10;
const name = "Dicoding";
console.log(`Aku ${name}, umurku ${age} tahun`);

// statement
const umur = 10;
const nama = "Dicoding";
console.log(`Aku ${nama}, umurku ${umur} tahun`);
