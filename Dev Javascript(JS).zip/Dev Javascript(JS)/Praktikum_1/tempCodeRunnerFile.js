// mengubah number ke string secara implisit
const age = 20;
const message = "umurku: " + age;
console.log(message); // umurku: 20
