// Teks ini akan diabaikan oleh interpreter
console.log("Hai, Readers!");
console.log("Hai, Javascript!");
// console.log('Hai, Dicoding!);

/*
* TODO
1. Buatlah variable bernama 'PI' dan di isikan dengan nilai 3.14
2. cetak nilai variable PI di terminal menggunakan console.log
*/
