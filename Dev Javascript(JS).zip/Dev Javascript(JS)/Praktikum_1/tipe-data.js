// // string
// "ini merupakan contoh string di JavaScipt";
// "ini merupakan contoh string di JavaScipt";
// "ini merupakan contoh string di JavaScipt";

// ("Baris pertama.\nBaris kedua.");
// ("Baris pertama.\nBaris kedua.");
// `Baris pertama.
// Baris kedua`;

// const currentYear = new Date().getFullYear();
// const text = `Sekarang adalah tahun ${currentYear}`;

// console.log(text); // sekarang adalah tahun 2024

// number
40;
3, 14;
5;
3.333;

const result = 50 / 0;
console.log(result); // infinity

const result = Number("chalisun");
console.log(result); // NaN

// boolean
const completed = true;
const passed = false;
console.log(completed, passed); // true false

const isGreater = 5 > 2;
console.log(isGreater); // true

// null
let message = null;
console.log(message); // null

// undefined
let message;
console.log(message); // undefined

let message = undefined;
console.log(message); // undefined
