// double quotes section
let doubleQuotes = "Belajar JavaScript bersama Asepp";
console.log(doubleQuotes);

// single quotes section
let singleQuotes = "Belajar JavaScript bersama Asepp";
console.log(singleQuotes);

// backticks section
let kalimatbakTicks = `Belajar Javascript bersama Asepp`;
console.log(kalimatbakTicks);
