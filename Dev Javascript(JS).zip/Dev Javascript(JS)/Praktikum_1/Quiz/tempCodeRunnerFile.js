// Jika menggunakan operator * pada string dan num
const strNumber = "123";
const result = strNumber * 2;

console.log(result); // Output: 246