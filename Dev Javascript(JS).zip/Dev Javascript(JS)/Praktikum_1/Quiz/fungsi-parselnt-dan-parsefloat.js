// string to number
const stringInt = "123";
const parsedInt = parseInt(stringInt);
console.log(parsedInt);

// string to float
const stringFloat = "3.14";
const parsedFloat = parseFloat(stringFloat);
console.log(parsedFloat);
