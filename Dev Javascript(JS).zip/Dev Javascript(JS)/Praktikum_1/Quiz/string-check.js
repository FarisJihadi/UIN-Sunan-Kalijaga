const age = 20;
const message = "Umurku " + age;

console.log(message); // Output: Umurku: 20
console.log(typeof message); // Output: string
