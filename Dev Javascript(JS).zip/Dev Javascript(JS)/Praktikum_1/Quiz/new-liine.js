// Double quotes section
const doubleQuotes = "Baris pertama. \nBaris pertama.";
console.log(doubleQuotes);

// Single quotes section
const singleQuotes = "Baris pertama. \nBaris kedua.";
console.log(singleQuotes);

// Bacticks section
const kalimatbackTicks = `Baris pertama.
Baris kedua.`;
console.log(kalimatbackTicks);
