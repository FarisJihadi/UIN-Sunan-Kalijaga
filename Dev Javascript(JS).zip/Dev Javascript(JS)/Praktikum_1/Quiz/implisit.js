// // Jika menggunakan operator * pada string dan num
// const strNumber = "123";
// const result = strNumber * 2;

// console.log(result); // Output: 246

// Jika menggunakan operator + pada num dan bool
const bool = true;
const result = 1 + bool;

console.log(result); // Output: 2
