const name1 = { first: "ahmad", last: null };
const name2 = { first: "ahmad", last: undefined };

console.log(JSON.stringify(name1)); //null
console.log(JSON.stringify(name2)); //nulll
