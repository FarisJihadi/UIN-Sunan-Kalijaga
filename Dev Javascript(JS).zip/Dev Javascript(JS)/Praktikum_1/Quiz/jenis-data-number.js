const intValue1 = 40;
console.log(intValue1);

const floatValue1 = 3.14;
console.log(floatValue1);

const intValue2 = 5;
console.log(intValue2);

const floatValue2 = 3.333;
console.log(floatValue2);
