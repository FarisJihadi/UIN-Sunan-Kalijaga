console.log(square(5)); // 25
function square(n) {
  return n * n;
}
