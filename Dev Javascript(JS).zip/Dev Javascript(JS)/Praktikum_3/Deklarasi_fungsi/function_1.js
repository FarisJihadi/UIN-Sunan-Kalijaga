function square(number) {
  return number * number;
}
