const square = function (number) {
  return number * number;
};

console.log(square(4)); // 16
