const foo = functio BarProp() {
    // statements go here
};