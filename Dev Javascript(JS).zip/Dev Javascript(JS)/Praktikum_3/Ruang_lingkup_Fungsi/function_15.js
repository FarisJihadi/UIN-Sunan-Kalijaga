let x = 0;
// "x < 10" is the loop condition
while (x < 10) {
  // doo stuff
  x++;
}
