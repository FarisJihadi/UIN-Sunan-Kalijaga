function salam(nama = "Pengunjung") {
  return `Halo, ${nama}!`;
}

console.log(salam()); // Output: "Halo, Pengunjung!"
console.log(salam("Budi")); // Output: "Halo, Budi!"
