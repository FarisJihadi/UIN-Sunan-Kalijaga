const kuadrat = function (angka) {
  return angka * angka;
};

console.log(kuadrat(6)); // Output: 36
