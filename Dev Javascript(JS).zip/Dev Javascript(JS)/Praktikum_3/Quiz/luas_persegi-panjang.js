function hitungLuasPersegiPanjang(panjang, lebar) {
  return panjang * lebar;
}

console.log(hitungLuasPersegiPanjang(5, 10)); // Output: 50
